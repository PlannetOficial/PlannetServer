﻿using PlannetServer.Shared.Kernel.BuildingBlocks;
using System;

namespace PlannetServer.Core.Aggregates.Promotions
{
    public class PromotionId : TypedIdValueBase
    {
        public PromotionId(Guid value)
            : base(value) { }

        public static implicit operator PromotionId(Guid promotionId)
            => new PromotionId(promotionId);
    }
}
