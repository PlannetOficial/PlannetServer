﻿namespace PlannetServer.Core.Events.Users
{
    internal class UserCreated
    {
    }
}
