﻿using PlannetServer.Shared.Kernel.BuildingBlocks;
using System;

namespace PlannetServer.Core.Aggregates.InfoCompany
{
    public class InfoCompanyId : TypedIdValueBase
    {
        public InfoCompanyId(Guid value)
            : base(value) { }

        public static implicit operator InfoCompanyId(Guid infoCompanyId)
            => new(infoCompanyId);
    }
}
