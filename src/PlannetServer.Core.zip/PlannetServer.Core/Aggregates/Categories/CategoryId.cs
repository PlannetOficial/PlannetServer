﻿using PlannetServer.Shared.Kernel.BuildingBlocks;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PlannetServer.Core.Aggregates.Categories
{
    public class CategoryId : TypedIdValueBase
    {
        public CategoryId(Guid value)
            : base(value) { }

        public static implicit operator CategoryId(Guid categoryId)
            => new CategoryId(categoryId);
    }
}
