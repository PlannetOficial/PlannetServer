﻿using PlannetServer.Shared.Kernel.BuildingBlocks;
using System;

namespace PlannetServer.Core.Aggregates.Communities
{
    public class CommunityId : TypedIdValueBase
    {
        public CommunityId(Guid value)
            : base(value) { }

        public static implicit operator CommunityId(Guid communityId)
            => new CommunityId(communityId);
    }
}
