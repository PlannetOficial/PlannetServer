﻿
using PlannetServer.Core.Aggregates.Communities;
using PlannetServer.Core.Aggregates.InfoCompany;
using PlannetServer.Core.Aggregates.Users;
using PlannetServer.Core.Entities.PostCategoryRelation;
using PlannetServer.Core.Entities.PostUserRelation;
using PlannetServer.Shared.Kernel.BuildingBlocks;
using System;
using System.Collections.Generic;

namespace PlannetServer.Core.Aggregates.Posts
{
    public class Post : AggregateRoot
    {
        private ISet<PostCategoryRelation> _categories = new HashSet<PostCategoryRelation>();
        private ISet<PostUserRelation> _users = new HashSet<PostUserRelation>();

        public PostId Id { get; private set; }
        public int? AbilityLevel { get; private set; }
        public string Address { get; private set; }
        public CommunityId? CommunityId { get; private set; }
        public decimal? Cost { get; private set; }
        public DateTimeOffset CreationDate { get; private set; }
        public string Description { get; private set; }
        public int GroupLimit { get; private set; }
        public InfoCompanyId HostCompanyId { get; private set; }
        public string ImgUrl { get; private set; }
        public bool IsAccessible { get; private set; }
        public string Location { get; private set; }
        public int? MaxParticipants { get; private set; }
        public string NecessaryEquipment { get; private set; }
        public DateTimeOffset? PlanDate { get; private set; }
        public string Title { get; private set; }
        public UserId UserId { get; private set; }

        public IEnumerable<PostCategoryRelation> Categories => _categories;
        public IEnumerable<PostUserRelation> Users => _users;

        private Post() { }

        public Post(PostId id, int? abilityLevel, string address, CommunityId? communityId, decimal? cost, DateTimeOffset creationDate, string description, int groupLimit, InfoCompanyId hostCompanyId, string imgUrl, bool isAccessible, string location, int? maxParticipants, string necessaryEquipment, DateTimeOffset? planDate, string title, UserId userId)
        {
            Id = id;
            AbilityLevel = abilityLevel;
            Address = address ?? throw new ArgumentNullException(nameof(address));
            CommunityId = communityId;
            Cost = cost;
            CreationDate = creationDate;
            Description = description ?? throw new ArgumentNullException(nameof(description));
            GroupLimit = groupLimit;
            HostCompanyId = hostCompanyId ?? throw new ArgumentNullException(nameof(hostCompanyId));
            ImgUrl = imgUrl ?? throw new ArgumentNullException(nameof(imgUrl));
            IsAccessible = isAccessible;
            Location = location ?? throw new ArgumentNullException(nameof(location));
            MaxParticipants = maxParticipants;
            NecessaryEquipment = necessaryEquipment ?? throw new ArgumentNullException(nameof(necessaryEquipment));
            PlanDate = planDate;
            Title = title ?? throw new ArgumentNullException(nameof(title));
            UserId = userId ?? throw new ArgumentNullException(nameof(userId));
        }

        public void AddCategory(PostCategoryRelation categoryRelation)
        {
            _categories.Add(categoryRelation);
        }

        public void AddUser(PostUserRelation userRelation)
        {
            _users.Add(userRelation);
        }
    }
}
