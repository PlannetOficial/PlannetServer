﻿using PlannetServer.Shared.Kernel.BuildingBlocks;
using System;

namespace PlannetServer.Core.Entities.UserFollows
{
    public sealed class UserFollowsId : TypedIdValueBase
    {
        public UserFollowsId(Guid value)
            : base(value) { }

        public static implicit operator UserFollowsId(Guid userFollowsId)
            => new UserFollowsId(userFollowsId);
    }
}
