﻿using System;
using PlannetServer.Core.Aggregates.Posts;
using PlannetServer.Core.Aggregates.Users;
using PlannetServer.Shared.Kernel.BuildingBlocks;

namespace PlannetServer.Core.Entities.PostUserRelation
{
    public class PostUserRelation : IEntity<PostUserRelationId>
    {
        public PostUserRelationId Id { get; private set; }
        public PostId PostId { get; private set; }
        public UserId UserId { get; private set; }

        private PostUserRelation() { }

        public PostUserRelation(PostUserRelationId id, PostId postId, UserId userId)
        {
            Id = id;
            PostId = postId;
            UserId = userId;
        }
    }
}
