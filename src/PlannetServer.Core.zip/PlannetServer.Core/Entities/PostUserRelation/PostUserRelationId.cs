﻿using PlannetServer.Shared.Kernel.BuildingBlocks;
using System;

namespace PlannetServer.Core.Entities.PostUserRelation
{
    public sealed class PostUserRelationId : TypedIdValueBase
    {
        public PostUserRelationId(Guid value)
            : base(value) { }

        public static implicit operator PostUserRelationId(Guid postUserRelationId)
            => new PostUserRelationId(postUserRelationId);
    }
}
