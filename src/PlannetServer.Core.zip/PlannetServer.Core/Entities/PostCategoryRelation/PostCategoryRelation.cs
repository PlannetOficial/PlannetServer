﻿using System;
using PlannetServer.Core.Aggregates.Categories;
using PlannetServer.Core.Aggregates.Posts;
using PlannetServer.Shared.Kernel.BuildingBlocks;

namespace PlannetServer.Core.Entities.PostCategoryRelation
{
    public class PostCategoryRelation : IEntity<PostCategoryRelationId>
    {
        public PostCategoryRelationId Id { get; private set; }
        public PostId PostId { get; private set; }
        public CategoryId CategoryId { get; private set; }

        private PostCategoryRelation() { }

        public PostCategoryRelation(PostCategoryRelationId id, PostId postId, CategoryId categoryId)
        {
            Id = id;
            PostId = postId;
            CategoryId = categoryId;
        }
    }
}
