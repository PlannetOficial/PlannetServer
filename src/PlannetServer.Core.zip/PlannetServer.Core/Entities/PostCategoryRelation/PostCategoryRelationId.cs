﻿using PlannetServer.Shared.Kernel.BuildingBlocks;
using System;

namespace PlannetServer.Core.Entities.PostCategoryRelation
{
    public sealed class PostCategoryRelationId : TypedIdValueBase
    {
        public PostCategoryRelationId(Guid value)
            : base(value) { }

        public static implicit operator PostCategoryRelationId(Guid postCategoryRelationId)
            => new PostCategoryRelationId(postCategoryRelationId);
    }
}
