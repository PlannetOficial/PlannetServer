﻿using PlannetServer.Shared.Kernel.BuildingBlocks;
using System;

namespace PlannetServer.Core.Entities.UserCommunityRelation
{
    public sealed class UserCommunityRelationId : TypedIdValueBase
    {
        public UserCommunityRelationId(Guid value)
            : base(value) { }

        public static implicit operator UserCommunityRelationId(Guid userCommunityRelationId)
            => new UserCommunityRelationId(userCommunityRelationId);
    }
}
