﻿using PlannetServer.Core.Aggregates.Communities;
using PlannetServer.Core.Aggregates.Users;
using PlannetServer.Core.Types;
using PlannetServer.Shared.Kernel.BuildingBlocks;

namespace PlannetServer.Core.Entities.UserCommunityRelation
{
    public class UserCommunityRelation : IEntity<UserCommunityRelationId>
    {
        public UserCommunityRelationId Id { get; private set; }
        public UserId UserId { get; private set; }
        public CommunityId CommunityId { get; private set; }
        public UserCommunityRelationType Type { get; set; }


        private UserCommunityRelation() { }

        public UserCommunityRelation(UserCommunityRelationId id, UserId userId, CommunityId communityId, int type)
        {
            Id = id;
            UserId = userId;
            CommunityId = communityId;
            Type = type;
        }
    }
}
