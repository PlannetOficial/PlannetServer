﻿namespace PlannetServer.Core.Types
{
    public enum UserCommunityRelationType
    {
        Member = 0,
        Admin = 1
    }
}
