namespace PlannetServer.Core.Types
{
    public enum OrderStatus
    {
        Canceled,
        Ended,
        Paid,
        Pending
    }
}
