﻿using PlannetServer.Core.Aggregates;
using PlannetServer.Core.Aggregates.Posts;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace PlannetServer.Core.Repositories
{
    internal interface IPostsRepository
    {
        Task<Post> GetAsync(Guid id);
        Task<IEnumerable<Post>> BrowseAsync();
        Task AddAsync(Post order);
        Task UpdateAsync(Post order);
    }
}
