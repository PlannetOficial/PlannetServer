using System.Collections.Generic;
using PlannetServer.Application.DTOs;
using MediatR;

namespace PlannetServer.Application.Queries
{
    public class GetOrders : IRequest<IEnumerable<OrderDto>> { }
}
