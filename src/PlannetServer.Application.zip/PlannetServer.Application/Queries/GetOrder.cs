using System;
using PlannetServer.Application.DTOs;
using MediatR;

namespace PlannetServer.Application.Queries
{
    public class GetOrder : IRequest<OrderDto>
    {
        public Guid Id { get; set; }
    }
}
