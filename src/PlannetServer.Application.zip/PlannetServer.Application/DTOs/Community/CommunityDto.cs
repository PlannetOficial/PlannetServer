namespace PlannetServer.Application.DTOs.Community;

public class CommunityDto
{
    public required long Id { get; set; }
    public required string Name { get; set; }
    public required string ImgUrl { get; set; }
}
