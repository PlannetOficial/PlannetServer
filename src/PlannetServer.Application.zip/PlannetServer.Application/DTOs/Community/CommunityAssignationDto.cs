using PlannetServer.Application.DTOs.Community;
using PlannetServer.Core.Types;

namespace PlannetServer.Application.Dtos.Commmunity;


public class CommunityAssignationDto
{
    public required CommunityDto Community { get; set; }
    public required UserCommunityRelationType Role { get; set; }
}
