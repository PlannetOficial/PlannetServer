using PlannetServer.Application.DTOs.Category;
using System;
using System.Collections.Generic;

namespace PlannetServer.Application.DTOs.Post;

public class CreatePostDto
{
    public required string Title { get; set; }
    public required string Description { get; set; }
    public required string ImgUrl { get; set; }
    public DateTimeOffset? PlanDate { get; set; }
    public required string UserId { get; set; }
    public required ICollection<CategoryDto> Categories { get; set; }
    public string? Address { get; set; }
    public LocationDto? Location { get; set; }
    public decimal? Cost { get; set; }
    public string? HostCompanyId { get; set; }
    public int? MaxParticipants { get; set; }
    public int? AbilityLevel { get; set; }
    public bool? IsAccessible { get; set; }
    public string? NecessaryEquipment { get; set; }
    public long? CommunityId { get; set; }
}
