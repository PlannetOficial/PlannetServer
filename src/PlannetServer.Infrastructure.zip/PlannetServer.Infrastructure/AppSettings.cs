namespace PlannetServer.Infrastructure
{
    public class AppSettings
    {
        public string Name { get; set; }
        public string Instance { get; set; }
        public string Version { get; set; }
    }
}
