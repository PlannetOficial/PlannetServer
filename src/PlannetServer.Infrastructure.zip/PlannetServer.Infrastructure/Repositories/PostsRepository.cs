﻿using Microsoft.EntityFrameworkCore;
using PlannetServer.Core.Aggregates.Posts;
using PlannetServer.Core.Repositories;
using PlannetServer.Infrastructure.Data;

namespace PlannetServer.Infrastructure.Repositories
{
    internal class PostsRepository : IPostsRepository
    {
        private readonly ApplicationDbContext _dbContext;

        public PostsRepository(ApplicationDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task AddAsync(Post post)
        {
            await _dbContext.Posts.AddAsync(post);
        }

        public async Task<IEnumerable<Post>> BrowseAsync()
        {
            return await _dbContext.Posts.ToListAsync();
        }

        public async Task<Post> GetAsync(Guid id)
        {
            var post = await _dbContext.Posts.FindAsync(id);
            if (post == null)
            {
                throw new KeyNotFoundException($"Post with id {id} not found.");
            }
            return post;
        }

        public async Task UpdateAsync(Post post)
        {
            _dbContext.Posts.Update(post);
            await _dbContext.SaveChangesAsync();
        }
    }
}
