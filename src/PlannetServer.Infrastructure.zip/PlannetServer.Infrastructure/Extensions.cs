using System;
using PlannetServer.Core.Repositories;
using PlannetServer.Shared.Exceptions;
using PlannetServer.Shared;
using PlannetServer.Shared.Contexts;
using PlannetServer.Shared.Swagger;
using PlannetServer.Infrastructure.Repositories;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using PlannetServer.Application;
using MediatR;

namespace PlannetServer.Infrastructure
{
    public static class Extensions
    {
        private const string CorrelationIdKey = "correlation-id";

        public static IServiceCollection AddInfrastructure(this IServiceCollection services)
        {
            services.AddErrorHandling();
            services.AddShared();
            services.AddContext();
            services.AddSwaggerDocs();
            services.AddMediatR(typeof(Extensions).Assembly, typeof(Application.Extensions).Assembly);
            
            services.AddSingleton(services.GetOptions<AppSettings>("app"));

            services.AddTransient<IOrdersRepository, OrdersRepository>();
            services.AddTransient<IPostsRepository, PostsRepository>();

            return services;
        }


        public static IApplicationBuilder UseInfrastructure(this IApplicationBuilder app)
        {
            app.UseCorrelationId();

            app.UseErrorHandling();

            app.UseSwaggerDocs();

            app.UseHttpsRedirection();

            app.UseContext();

            app.UseRouting();

            app.UseAuthorization();

            return app;
        }

    }
}
